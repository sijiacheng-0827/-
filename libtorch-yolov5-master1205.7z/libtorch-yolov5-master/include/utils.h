#pragma once

enum Det {
    tl_x = 0,
    tl_y = 1,
    br_x = 2,
    br_y = 3,
    score = 4,
    class_idx = 1
};

struct Detection {
    cv::Rect bbox;
    float score;
    int class_idx;
};